module Unicode
  module DisplayWidth
    NO_STRING_EXT = true
  end
end

require_relative '../display_width'
