class ProgressBar
  VERSION = '1.11.0'.freeze
end
