module SimpleCov
  module Formatter
    class HTMLFormatter
      VERSION = "0.10.2".freeze
    end
  end
end
