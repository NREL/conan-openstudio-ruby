0.10.2 2017-08-14
========

## Bugfixes

* Allow usage with frozen-string-literal-enabled. See [#56](https://github.com/colszowka/simplecov-html/pull/56) (thanks @pat)

0.10.1 2017-05-17 
========

## Bugfixes

* circumvent a regression that happens in the new JRuby 9.1.9.0 release. See [#53](https://github.com/colszowka/simplecov-html/pull/53) thanks @koic
