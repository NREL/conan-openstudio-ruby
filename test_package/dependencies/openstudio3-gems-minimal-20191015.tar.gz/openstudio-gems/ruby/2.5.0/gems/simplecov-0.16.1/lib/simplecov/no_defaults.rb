# frozen_string_literal: true

ENV["SIMPLECOV_NO_DEFAULTS"] = "yes, no defaults"
require "simplecov"
