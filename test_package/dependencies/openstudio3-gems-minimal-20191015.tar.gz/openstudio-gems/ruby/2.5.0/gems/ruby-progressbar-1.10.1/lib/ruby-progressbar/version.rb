class ProgressBar
  VERSION = '1.10.1'.freeze
end
