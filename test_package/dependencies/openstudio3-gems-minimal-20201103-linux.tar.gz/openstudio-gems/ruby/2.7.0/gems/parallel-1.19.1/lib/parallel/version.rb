module Parallel
  VERSION = Version = '1.19.1'
end
