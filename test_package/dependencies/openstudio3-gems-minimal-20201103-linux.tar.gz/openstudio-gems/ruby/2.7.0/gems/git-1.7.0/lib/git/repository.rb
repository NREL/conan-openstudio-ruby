module Git

  class Repository < Path
  end

end
