module Git
  # The current gem version
  # @return [String] the current gem version.
  VERSION='1.7.0'
end
