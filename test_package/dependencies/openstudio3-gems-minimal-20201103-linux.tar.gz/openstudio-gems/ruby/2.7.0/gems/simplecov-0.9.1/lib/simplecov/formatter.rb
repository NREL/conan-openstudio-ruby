module SimpleCov
  # TODO: Documentation on how to build your own formatters
  module Formatter
  end
end

require 'simplecov/formatter/simple_formatter'
require 'simplecov/formatter/multi_formatter'
