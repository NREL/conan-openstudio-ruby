ENV['SIMPLECOV_NO_DEFAULTS'] = 'yes, no defaults'
require 'simplecov'
