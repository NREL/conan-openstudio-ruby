module SimpleCov
  VERSION = "0.9.1"
end
