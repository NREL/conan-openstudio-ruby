# encoding: utf-8

puts '135°C'
